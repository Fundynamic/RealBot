Please see the files in the "html" or "txt" directory for documentation.

Example files in the current directory:

   plugins.ini
   config.ini
