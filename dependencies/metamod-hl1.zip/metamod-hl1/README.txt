Metamod Half-Life utility mod

See the files under "doc/txt" or "doc/html" for more information.

Will Day
willday@metamod.org
http://www.metamod.org/
